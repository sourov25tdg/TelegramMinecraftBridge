package com.sourov.telegrambridge;

import com.google.gson.*;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.atomic.AtomicBoolean;

public final class TelegramMinecraftBridge extends JavaPlugin implements Listener {

    private final HttpClient http = HttpClient.newHttpClient();
    private final Gson gson = new Gson();
    private String token;
    private long adminId;
    private int pollSeconds;
    private boolean forwardChat;
    private boolean enableSay;
    private long offset = 0;
    private final AtomicBoolean polling = new AtomicBoolean(false);

    @Override
    public void onEnable() {
        saveDefaultConfig();

        token = getConfig().getString("bot-token", "");
        adminId = getConfig().getLong("admin-id", 0);
        pollSeconds = Math.max(1, getConfig().getInt("poll-interval-seconds", 2));
        forwardChat = getConfig().getBoolean("forward-minecraft-chat", true);
        enableSay = getConfig().getBoolean("enable-say", true);

        if (token.isBlank() || token.contains("PASTE_NEW_BOTFATHER_TOKEN")) {
            getLogger().severe("Set bot-token in plugins/TelegramMinecraftBridge/config.yml");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        if (adminId == 0) {
            getLogger().severe("Set admin-id in config.yml");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        Bukkit.getPluginManager().registerEvents(this, this);
        startPolling();

        getLogger().info("TelegramMinecraftBridge enabled.");
    }

    @Override
    public void onDisable() {
        polling.set(false);
        getLogger().info("TelegramMinecraftBridge disabled.");
    }

    private void startPolling() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(
                this,
                this::pollTelegram,
                20L,
                pollSeconds * 20L
        );
    }

    private void pollTelegram() {
        if (!polling.compareAndSet(false, true)) return;

        try {
            String url = "https://api.telegram.org/bot" + token
                    + "/getUpdates?timeout=0&offset=" + offset;

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response =
                    http.send(request, HttpResponse.BodyHandlers.ofString());

            JsonObject root = gson.fromJson(response.body(), JsonObject.class);
            if (!root.get("ok").getAsBoolean()) return;

            JsonArray updates = root.getAsJsonArray("result");

            for (JsonElement element : updates) {
                JsonObject update = element.getAsJsonObject();
                offset = update.get("update_id").getAsLong() + 1;

                if (!update.has("message")) continue;

                JsonObject message = update.getAsJsonObject("message");
                if (!message.has("from") || !message.has("chat")) continue;

                long userId = message.getAsJsonObject("from").get("id").getAsLong();
                long chatId = message.getAsJsonObject("chat").get("id").getAsLong();

                if (userId != adminId) {
                    sendTelegram(chatId, "❌ You are not authorized.");
                    continue;
                }

                if (!message.has("text")) continue;

                String text = message.get("text").getAsString().trim();
                handleTelegramCommand(chatId, text);
            }
        } catch (Exception e) {
            getLogger().warning("Telegram polling error: " + e.getMessage());
        } finally {
            polling.set(false);
        }
    }

    private void handleTelegramCommand(long chatId, String text) {
        if (text.equalsIgnoreCase("/start") || text.equalsIgnoreCase("/help")) {
            sendTelegram(chatId,
                    "🎮 Minecraft Telegram Bridge\n\n" +
                    "/status - Server status\n" +
                    "/players - Online players\n" +
                    "/say <message> - Send message to Minecraft");
            return;
        }

        if (text.equalsIgnoreCase("/status")) {
            sendTelegram(chatId,
                    "🟢 Server is online.\n" +
                    "Players: " + Bukkit.getOnlinePlayers().size() +
                    "/" + Bukkit.getMaxPlayers());
            return;
        }

        if (text.equalsIgnoreCase("/players")) {
            StringBuilder sb = new StringBuilder("👥 Online Players\n\n");
            if (Bukkit.getOnlinePlayers().isEmpty()) {
                sb.append("No players online.");
            } else {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    sb.append("• ").append(player.getName()).append("\n");
                }
            }
            sendTelegram(chatId, sb.toString());
            return;
        }

        if (text.regionMatches(true, 0, "/say", 0, 4)) {
            if (!enableSay) {
                sendTelegram(chatId, "❌ /say is disabled.");
                return;
            }

            String message = text.length() > 4 ? text.substring(4).trim() : "";
            if (message.isBlank()) {
                sendTelegram(chatId, "Usage: /say Hello Minecraft");
                return;
            }

            Bukkit.getScheduler().runTask(this, () ->
                    Bukkit.broadcastMessage("§b[Telegram] §f" + message)
            );

            sendTelegram(chatId, "📨 Sent to Minecraft:\n" + message);
            return;
        }

        sendTelegram(chatId, "❓ Unknown command. Use /help");
    }

    @EventHandler
    public void onMinecraftChat(AsyncChatEvent event) {
        if (!forwardChat) return;

        String player = event.getPlayer().getName();
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());

        sendTelegramAsync("💬 [" + player + "] " + message);
    }

    private void sendTelegramAsync(String message) {
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> sendTelegram(adminId, message));
    }

    private void sendTelegram(long chatId, String text) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("chat_id", chatId);
            body.addProperty("text", text);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.telegram.org/bot" + token + "/sendMessage"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)))
                    .build();

            http.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            getLogger().warning("Telegram send error: " + e.getMessage());
        }
    }
}
